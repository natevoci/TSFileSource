//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by PropPage.rc
//
#define IDS_PROPPAGE_TITLE              1
#define IDD_PROPPAGE                    101
#define IDC_VIDEO                       1000
#define IDC_AUDIO2                      1001
#define IDC_AUDIO                       1002
#define IDC_ECM                         1003
#define IDC_SID                         1003
#define IDC_AC3                         1004
#define IDC_PMT                         1005
#define IDC_DURATION                    1006
#define IDC_STARTTIME                   1008
#define IDC_PCR                         1009

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        102
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1011
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
